NoticeOS design system v2.
Extract this folder and open design-system.html in a browser.
Examples use illustrative data and do not call NoticeOS APIs.
The Inter and Stack Sans Notch font licenses (SIL Open Font License 1.1) are in fonts/.
The Notice mark is the Notice company mark; it is not licensed with the source code.
Provider trademarks, provenance and asset hashes are documented in integrations/.
